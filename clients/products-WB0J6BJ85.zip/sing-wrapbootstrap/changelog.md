
Changelog
--

**Version 1.2.0**

  - Bootstrap 3.3.4 update

Version 1.2.0 upgrade instructions

1.2.0 upgrade introduces no new features, so no special steps needed.

**Version 1.1.1**

  - Angular Datatables fix (Angular version)

Version 1.1.1 upgrade instructions

Following files are changed:

  - angular/js/ng/app.js
  - angular/index.html


**Version 1.1.0**

  - Bootstrap 3.3 update
  - Angular 1.3.8 update
  - Font awesome 4.3.0

Version 1.1.0 upgrade instructions

1.1.0 upgrade introduces no new features. It just updates libraries to their newest versions (March 2015), so it requires no additional steps when updating.
You may simply replace main templates files: `bower.json`, `application.scss` and javascripts.
